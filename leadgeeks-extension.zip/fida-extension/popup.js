// Fida Neo AI SDR - Popup Script

let playbooks = [];
let activePlaybookId = null;

function init() {
  // Load playbooks + leads
  chrome.runtime.sendMessage({ type: 'GET_PLAYBOOKS' }, (res) => {
    playbooks = res?.playbooks || [];
    activePlaybookId = res?.activePlaybookId || null;
    renderPlaybooks();
  });

  chrome.runtime.sendMessage({ type: 'GET_LEAD_COUNT' }, (res) => {
    document.getElementById('popLeadCount').textContent = res?.count || 0;
  });

  // Load recent leads for preview
  chrome.storage.local.get(['fidaQueuedLeads'], (data) => {
    const leads = data.fidaQueuedLeads ? JSON.parse(data.fidaQueuedLeads) : [];
    renderLeadList(leads);
  });
}

function renderPlaybooks() {
  const sel = document.getElementById('popPbSelect');
  const noPbMsg = document.getElementById('popNoPbMsg');

  if (!playbooks.length) {
    sel.innerHTML = '<option value="">-- No playbooks --</option>';
    noPbMsg.style.display = 'block';
    return;
  }

  noPbMsg.style.display = 'none';
  sel.innerHTML = '<option value="">-- Select playbook --</option>' +
    playbooks.map(pb =>
      `<option value="${pb.id}" ${pb.id === activePlaybookId ? 'selected' : ''}>${pb.name}</option>`
    ).join('');
}

function renderLeadList(leads) {
  const list = document.getElementById('popLeadList');
  if (!leads.length) {
    list.innerHTML = '<div class="empty">No leads yet -- browse LinkedIn to add some</div>';
    return;
  }

  // Show most recent 8
  const recent = [...leads].reverse().slice(0, 8);
  list.innerHTML = recent.map(l => {
    const pb = playbooks.find(p => p.id === l.playbookId);
    return `
      <div class="lead-item">
        <div class="lead-info">
          <div class="lead-name">${l.fullName || 'Unknown'}</div>
          <div class="lead-meta">${[l.title, l.company].filter(Boolean).join(' · ') || l.location || ''}</div>
        </div>
        ${pb ? `<div class="lead-pb">${pb.name.substring(0, 18)}${pb.name.length > 18 ? '...' : ''}</div>` : ''}
      </div>
    `;
  }).join('');
}

// Playbook change
document.getElementById('popPbSelect').addEventListener('change', (e) => {
  activePlaybookId = e.target.value || null;
  chrome.runtime.sendMessage({ type: 'SET_ACTIVE_PLAYBOOK', id: activePlaybookId });
  setStatus('Playbook updated!');
});

// Sync from app - opens app page and reads its localStorage
document.getElementById('popSyncBtn').addEventListener('click', () => {
  setStatus('Syncing...');
  // Open the app in a tab, let it post playbooks back
  chrome.tabs.query({ url: 'https://fida-sdr.netlify.app/*' }, (tabs) => {
    if (tabs.length > 0) {
      // App is open — send it a message to push its playbooks
      chrome.tabs.sendMessage(tabs[0].id, { type: 'REQUEST_PLAYBOOK_SYNC' }, (res) => {
        if (res?.ok) {
          setStatus(`Synced ${res.count} playbooks!`);
          setTimeout(init, 500);
        } else {
          // Try opening the app
          chrome.tabs.create({ url: 'https://fida-sdr.netlify.app', active: false });
          setStatus('App opened - sync in progress...');
          setTimeout(init, 2000);
        }
      });
    } else {
      chrome.tabs.create({ url: 'https://fida-sdr.netlify.app', active: false });
      setStatus('Opening app to sync...');
      setTimeout(init, 2500);
    }
  });
});

// Clear queue
document.getElementById('popClearBtn').addEventListener('click', () => {
  if (!confirm('Clear all queued leads?')) return;
  chrome.runtime.sendMessage({ type: 'CLEAR_LEADS' }, () => {
    document.getElementById('popLeadCount').textContent = '0';
    renderLeadList([]);
    setStatus('Queue cleared');
  });
});

function setStatus(msg) {
  const el = document.getElementById('popStatus');
  el.textContent = msg;
  setTimeout(() => { el.textContent = ''; }, 2500);
}

init();
