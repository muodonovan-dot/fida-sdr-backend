// Fida Neo AI SDR - Background Service Worker v2

// ── Storage helpers ──────────────────────────────────────
function getLeads(cb) {
  chrome.storage.local.get(['fidaQueuedLeads'], (d) => {
    cb(d.fidaQueuedLeads ? JSON.parse(d.fidaQueuedLeads) : []);
  });
}
function setLeads(leads, cb) {
  chrome.storage.local.set({ fidaQueuedLeads: JSON.stringify(leads) }, cb);
}

// ── Push leads to app tab ─────────────────────────────────
function pushLeadsToApp() {
  getLeads((leads) => {
    if (!leads.length) return;
    chrome.tabs.query({ url: 'https://fida-sdr.netlify.app/*' }, (tabs) => {
      if (!tabs || !tabs.length) return;
      // Send to the most recently active app tab
      const tab = tabs[0];
      chrome.tabs.sendMessage(tab.id, {
        type: 'PUSH_LEADS_TO_APP',
        leads: leads
      }, (res) => {
        if (chrome.runtime.lastError) return; // tab not ready yet
        if (res && res.ok) {
          // Clear leads after successful import
          setLeads([], () => updateBadge());
        }
      });
    });
  });
}

// ── Message handler ───────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === 'GET_PLAYBOOKS') {
    chrome.storage.sync.get(['fidaPlaybooks', 'fidaActivePlaybook'], (data) => {
      sendResponse({
        playbooks: data.fidaPlaybooks ? JSON.parse(data.fidaPlaybooks) : [],
        activePlaybookId: data.fidaActivePlaybook || null
      });
    });
    return true;
  }

  if (message.type === 'SET_ACTIVE_PLAYBOOK') {
    chrome.storage.sync.set({ fidaActivePlaybook: message.id }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.type === 'ADD_LEAD') {
    getLeads((existing) => {
      const isDuplicate = existing.some(l => {
        // Only deduplicate on URL (reliable) or full name+company when both non-empty
        if (l.linkedinUrl && message.lead.linkedinUrl && l.linkedinUrl === message.lead.linkedinUrl) return true;
        if (l.fullName && message.lead.fullName && l.company && message.lead.company &&
            l.fullName === message.lead.fullName && l.company === message.lead.company) return true;
        return false;
      });
      if (!isDuplicate) {
        existing.push({ ...message.lead, addedAt: Date.now() });
        setLeads(existing, () => {
          updateBadge();
          sendResponse({ ok: true, count: existing.length, duplicate: false });
        });
      } else {
        sendResponse({ ok: false, duplicate: true, count: existing.length });
      }
    });
    return true;
  }

  if (message.type === 'GET_LEAD_COUNT') {
    getLeads((leads) => sendResponse({ count: leads.length }));
    return true;
  }

  if (message.type === 'CLEAR_LEADS') {
    setLeads([], () => {
      updateBadge();
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.type === 'SYNC_PLAYBOOKS_FROM_APP') {
    chrome.storage.sync.set({
      fidaPlaybooks: JSON.stringify(message.playbooks),
      fidaActivePlaybook: message.activePlaybookId || null
    }, () => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'APP_TAB_READY') {
    // App tab just loaded and is ready - push any queued leads
    pushLeadsToApp();
    return false;
  }
});

// ── Badge ─────────────────────────────────────────────────
function updateBadge() {
  getLeads((leads) => {
    const count = leads.length;
    chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#EF4D05' });
  });
}

chrome.storage.onChanged.addListener(() => updateBadge());
chrome.runtime.onStartup.addListener(updateBadge);
chrome.runtime.onInstalled.addListener(updateBadge);

// When any app tab becomes active, push leads to it
chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab.url && tab.url.includes('fida-sdr.netlify.app')) {
      setTimeout(() => pushLeadsToApp(), 1000);
    }
  });
});
