// Fida Neo AI SDR - App Bridge v8
// Uses window.postMessage for zero-timing-issue communication

(function () {
  'use strict';

  function syncPlaybooks() {
    try {
      const raw = localStorage.getItem('fidaPlaybooks');
      const activeId = localStorage.getItem('fidaActivePlaybook');
      chrome.runtime.sendMessage({
        type: 'SYNC_PLAYBOOKS_FROM_APP',
        playbooks: raw ? JSON.parse(raw) : [],
        activePlaybookId: activeId
      });
    } catch(e) {}
  }

  // Listen for messages FROM the page (importFromExtension button)
  window.addEventListener('message', (e) => {
    if (!e.data) return;

    if (e.data.type === 'FIDA_REQUEST_LEADS') {
      // Page is asking for queued leads - get from local storage and send back
      chrome.storage.local.get(['fidaQueuedLeads'], (data) => {
        const leads = data.fidaQueuedLeads ? JSON.parse(data.fidaQueuedLeads) : [];
        window.postMessage({ type: 'FIDA_LEADS_RESPONSE', leads }, '*');
      });
    }

    if (e.data.type === 'FIDA_CLEAR_LEADS') {
      chrome.runtime.sendMessage({ type: 'CLEAR_LEADS' });
    }
  });

  // Also auto-push leads when page loads (bonus - works if timing is right)
  function autoPush() {
    chrome.storage.local.get(['fidaQueuedLeads'], (data) => {
      const leads = data.fidaQueuedLeads ? JSON.parse(data.fidaQueuedLeads) : [];
      if (leads.length > 0) {
        window.postMessage({ type: 'FIDA_LEADS_RESPONSE', leads }, '*');
      }
    });
  }

  function init() {
    syncPlaybooks();
    setTimeout(syncPlaybooks, 1500);
    window.addEventListener('storage', (e) => {
      if (e.key === 'fidaPlaybooks' || e.key === 'fidaActivePlaybook') syncPlaybooks();
    });
    // Try auto-push after app has loaded
    setTimeout(autoPush, 1000);
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'REQUEST_PLAYBOOK_SYNC') {
      syncPlaybooks();
      const raw = localStorage.getItem('fidaPlaybooks');
      sendResponse({ ok: true, count: raw ? JSON.parse(raw).length : 0 });
    }
    if (msg.type === 'PUSH_LEADS_TO_APP') {
      // Background pushing leads - forward to page via postMessage
      window.postMessage({ type: 'FIDA_LEADS_RESPONSE', leads: msg.leads }, '*');
      sendResponse({ ok: true });
    }
    return true;
  });

  setTimeout(init, 400);
})();
