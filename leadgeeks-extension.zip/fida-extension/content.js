// Fida Neo AI SDR - LinkedIn Content Script
// Runs on all linkedin.com pages

(function () {
  'use strict';

  let playbooks = [];
  let activePlaybookId = null;
  let leadCount = 0;
  let barInjected = false;
  let observer = null;

  // ── Load state from extension storage ───────────────────
  function loadState(cb) {
    chrome.runtime.sendMessage({ type: 'GET_PLAYBOOKS' }, (res) => {
      if (res) {
        playbooks = res.playbooks || [];
        activePlaybookId = res.activePlaybookId || null;
      }
      chrome.runtime.sendMessage({ type: 'GET_LEAD_COUNT' }, (res2) => {
        leadCount = res2?.count || 0;
        if (cb) cb();
        // If no playbooks found, try requesting sync from the app tab
        if (!playbooks.length) {
          requestSyncFromApp();
        }
      });
    });
  }

  function requestSyncFromApp() {
    chrome.tabs.query({ url: 'https://fida-sdr.netlify.app/*' }, (tabs) => {
      if (tabs && tabs.length > 0) {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'REQUEST_PLAYBOOK_SYNC' }, () => {
          // After sync, reload state and update bar
          setTimeout(() => {
            chrome.runtime.sendMessage({ type: 'GET_PLAYBOOKS' }, (res) => {
              if (res && res.playbooks && res.playbooks.length) {
                playbooks = res.playbooks;
                activePlaybookId = res.activePlaybookId || null;
                updateBarPlaybooks();
              }
            });
          }, 800);
        });
      }
    });
  }

  // ── Bottom Bar ───────────────────────────────────────────
  function injectBar() {
    if (document.getElementById('fida-bar')) return;

    const bar = document.createElement('div');
    bar.id = 'fida-bar';
    bar.innerHTML = `
      <div class="fida-logo">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="12" fill="#EF4D05"/>
          <path d="M7 8h10M7 12h7M7 16h5" stroke="#fff" stroke-width="2" stroke-linecap="round"/>
        </svg>
        Fida <span>Neo</span>
      </div>
      <div class="fida-divider"></div>
      <label>Playbook:</label>
      <select id="fida-pb-select">
        <option value="">-- No playbooks yet --</option>
      </select>
      <div class="fida-divider"></div>
      <div class="fida-count">Queue: <strong id="fida-lead-count">0</strong> leads</div>
      <a href="https://fida-sdr.netlify.app" target="_blank" class="fida-open-btn">
        Open App →
      </a>
    `;
    document.body.appendChild(bar);

    // Add padding to body so content isn't hidden behind bar
    document.body.style.paddingBottom = '52px';

    // Populate playbook dropdown
    updateBarPlaybooks();

    // Handle playbook change
    document.getElementById('fida-pb-select').addEventListener('change', (e) => {
      activePlaybookId = e.target.value || null;
      chrome.runtime.sendMessage({ type: 'SET_ACTIVE_PLAYBOOK', id: activePlaybookId });
    });

    barInjected = true;
  }

  function updateBarPlaybooks() {
    const sel = document.getElementById('fida-pb-select');
    if (!sel) return;
    if (!playbooks.length) {
      sel.innerHTML = '<option value="">-- Create a playbook in the app first --</option>';
      return;
    }
    sel.innerHTML = '<option value="">-- Select playbook --</option>' +
      playbooks.map(pb =>
        `<option value="${pb.id}" ${pb.id === activePlaybookId ? 'selected' : ''}>${pb.name}</option>`
      ).join('');
    // Auto-select active playbook if set
    if (activePlaybookId) {
      sel.value = activePlaybookId;
    } else if (playbooks.length === 1) {
      // Auto-select if only one playbook
      sel.value = playbooks[0].id;
      activePlaybookId = playbooks[0].id;
    }
  }

  function updateLeadCount(count) {
    leadCount = count;
    const el = document.getElementById('fida-lead-count');
    if (el) el.textContent = count;
  }

  // ── Lead Card Button Injection ───────────────────────────
  function extractLeadFromCard(card) {
    // Works for both LinkedIn and Sales Navigator search results
    const name = (
      card.querySelector('[data-anonymize="person-name"]')?.textContent ||
      card.querySelector('.artdeco-entity-lockup__title')?.textContent ||
      card.querySelector('span[aria-hidden="true"]')?.textContent ||
      card.querySelector('a[href*="/in/"] span')?.textContent ||
      ''
    ).trim();

    const title = (
      card.querySelector('[data-anonymize="title"]')?.textContent ||
      card.querySelector('.artdeco-entity-lockup__subtitle')?.textContent ||
      card.querySelector('.entity-result__primary-subtitle')?.textContent ||
      ''
    ).trim();

    const company = (
      card.querySelector('[data-anonymize="company-name"]')?.textContent ||
      card.querySelector('.artdeco-entity-lockup__caption')?.textContent ||
      card.querySelector('.entity-result__secondary-subtitle')?.textContent ||
      ''
    ).trim();

    const location = (
      card.querySelector('[data-anonymize="location"]')?.textContent ||
      card.querySelector('.entity-result__tertiary-subtitle')?.textContent ||
      ''
    ).trim();

    // Try to get LinkedIn profile URL
    const linkEl = card.querySelector('a[href*="/in/"]') ||
                   card.querySelector('a[href*="sales/lead/"]') ||
                   card.querySelector('a[href*="sales/people/"]');
    const linkedinUrl = linkEl ? linkEl.href.split('?')[0] : '';

    // Extract first/last name
    const nameParts = name.split(' ');
    const firstName = nameParts[0] || '';
    const lastName = nameParts.slice(1).join(' ') || '';

    // Guess institution (company is usually org for academics)
    const institution = company || '';

    return { firstName, lastName, fullName: name, title, company, institution, location, linkedinUrl };
  }

  function injectAddButton(card) {
    // Don't inject twice
    if (card.querySelector('.fida-add-btn')) return;
    // Don't inject if no meaningful name found
    const lead = extractLeadFromCard(card);
    if (!lead.fullName || lead.fullName.length < 2) return;

    // Find the actions area in the card
    const actionsArea =
      card.querySelector('.artdeco-entity-lockup__metadata') ||
      card.querySelector('[class*="actions"]') ||
      card.querySelector('.entity-result__actions') ||
      card.querySelector('div[class*="action-container"]') ||
      card.querySelector('.lt-line-clamp__more') ||
      null;

    const btn = document.createElement('button');
    btn.className = 'fida-add-btn';
    btn.setAttribute('data-linkedin-url', lead.linkedinUrl);
    btn.innerHTML = '+ Add to Fida';

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      addLead(lead, btn);
    });

    // Find a good place to inject - prefer after the name/title area
    const insertTarget =
      card.querySelector('.artdeco-entity-lockup__title') ||
      card.querySelector('span.actor-name') ||
      actionsArea;

    if (insertTarget) {
      // Insert button after the element's parent or after itself
      const parent = insertTarget.closest('li') ||
                     insertTarget.parentElement;
      if (parent) {
        // Find or create an actions row
        let actionRow = parent.querySelector('.entity-result__actions') ||
                        parent.querySelector('[data-control-name="view_lead_panel_via_search_lead_name"]')?.parentElement;
        if (actionRow) {
          actionRow.appendChild(btn);
        } else {
          insertTarget.parentElement.appendChild(btn);
        }
      }
    } else {
      card.appendChild(btn);
    }
  }

  function addLead(lead, btn) {
    if (!activePlaybookId && playbooks.length > 0) {
      // Flash the dropdown to prompt selection
      const sel = document.getElementById('fida-pb-select');
      if (sel) {
        sel.style.borderColor = '#EF4D05';
        sel.style.boxShadow = '0 0 0 2px rgba(239,77,5,0.4)';
        setTimeout(() => {
          sel.style.borderColor = '';
          sel.style.boxShadow = '';
        }, 1500);
      }
      showToast('Select a playbook first!', 'warn');
      return;
    }

    const activePb = playbooks.find(p => p.id === activePlaybookId);
    const leadData = {
      ...lead,
      playbookId: activePlaybookId,
      playbookName: activePb?.name || '',
      source: 'linkedin_extension'
    };

    btn.textContent = '...';
    btn.disabled = true;

    chrome.runtime.sendMessage({ type: 'ADD_LEAD', lead: leadData }, (res) => {
      console.log('[FIDA] ADD_LEAD response:', JSON.stringify(res), '| lead:', lead.fullName, '|', lead.company);
      if (chrome.runtime.lastError) {
        console.log('[FIDA] runtime error:', chrome.runtime.lastError.message);
      }
      if (res?.duplicate) {
        btn.className = 'fida-add-btn fida-duplicate';
        btn.textContent = 'Already added';
        showToast(`${lead.fullName} already in queue`, 'info');
      } else if (res?.ok) {
        btn.className = 'fida-add-btn fida-added';
        btn.textContent = '✓ Added';
        // Always re-read count from storage to avoid stale badge
        chrome.runtime.sendMessage({ type: 'GET_LEAD_COUNT' }, (r2) => {
          updateLeadCount(r2?.count || res.count);
        });
        showToast(`${lead.firstName} added to ${activePb?.name || 'queue'}!`, 'success');
      } else {
        console.log('[FIDA] No response from background!');
        btn.textContent = '+ Add to Fida';
        btn.disabled = false;
      }
    });
  }

  // ── Toast Notification ───────────────────────────────────
  function showToast(msg, type = 'success') {
    const existing = document.getElementById('fida-toast');
    if (existing) existing.remove();

    const colors = {
      success: '#27ae60',
      warn: '#f0c040',
      info: '#3498db',
      error: '#e74c3c'
    };

    const toast = document.createElement('div');
    toast.id = 'fida-toast';
    toast.style.cssText = `
      position: fixed;
      bottom: 64px;
      right: 20px;
      background: #0f0d1e;
      border: 1px solid ${colors[type]};
      border-left: 4px solid ${colors[type]};
      color: #fff;
      padding: 10px 16px;
      border-radius: 8px;
      font-family: 'Segoe UI', system-ui, sans-serif;
      font-size: 13px;
      font-weight: 600;
      z-index: 999999;
      box-shadow: 0 4px 16px rgba(0,0,0,0.4);
      animation: fidaFadeIn 0.2s ease;
    `;
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
  }

  // ── Profile Page Panel ───────────────────────────────────
  function injectProfilePanel() {
    if (document.getElementById('fida-profile-panel')) return;

    // Find the sidebar on a LinkedIn profile page
    const sidebar = document.querySelector('.pv-top-card') ||
                    document.querySelector('main section') ||
                    document.querySelector('.scaffold-layout__sidebar');
    if (!sidebar) return;

    const name = (
      document.querySelector('h1')?.textContent ||
      document.querySelector('.pv-text-details__left-panel h1')?.textContent ||
      ''
    ).trim();

    const title = (
      document.querySelector('.pv-text-details__left-panel .text-body-medium')?.textContent ||
      document.querySelector('[data-generated-suggestion-target]')?.textContent ||
      ''
    ).trim();

    const company = (
      document.querySelector('.pv-text-details__right-panel-item-text')?.textContent ||
      document.querySelector('.inline-show-more-text--is-collapsed')?.textContent ||
      ''
    ).trim().split('\n')[0];

    const location = (
      document.querySelector('.pv-text-details__left-panel .text-body-small')?.textContent ||
      ''
    ).trim();

    const linkedinUrl = window.location.href.split('?')[0];
    const nameParts = name.split(' ');

    const lead = {
      firstName: nameParts[0] || '',
      lastName: nameParts.slice(1).join(' ') || '',
      fullName: name,
      title,
      company,
      institution: company,
      location,
      linkedinUrl
    };

    const panel = document.createElement('div');
    panel.id = 'fida-profile-panel';
    panel.innerHTML = `
      <div class="fida-panel-title">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="12" fill="#EF4D05"/>
          <path d="M7 8h10M7 12h7M7 16h5" stroke="#fff" stroke-width="2" stroke-linecap="round"/>
        </svg>
        Fida <span>Neo</span> AI SDR
      </div>
      <div class="fida-panel-row">
        <div class="fida-panel-label">Add to Playbook</div>
        <select id="fida-panel-pb-select">
          ${!playbooks.length
            ? '<option value="">-- Create a playbook first --</option>'
            : '<option value="">-- Select --</option>' + playbooks.map(pb =>
                `<option value="${pb.id}" ${pb.id === activePlaybookId ? 'selected' : ''}>${pb.name}</option>`
              ).join('')
          }
        </select>
      </div>
      <button class="fida-panel-add-btn" id="fida-panel-add-btn">
        + Add ${name ? name.split(' ')[0] : 'Lead'} to Queue
      </button>
      <div class="fida-panel-status" id="fida-panel-status"></div>
    `;

    // Insert panel at top of sidebar content
    sidebar.insertAdjacentElement('afterend', panel);

    // Handle add click
    document.getElementById('fida-panel-add-btn').addEventListener('click', () => {
      const pbId = document.getElementById('fida-panel-pb-select').value;
      if (!pbId && playbooks.length > 0) {
        document.getElementById('fida-panel-status').textContent = 'Select a playbook first';
        document.getElementById('fida-panel-status').style.color = '#f0c040';
        return;
      }
      const activePb = playbooks.find(p => p.id === pbId);
      const btn = document.getElementById('fida-panel-add-btn');
      btn.textContent = 'Adding...';
      btn.disabled = true;

      chrome.runtime.sendMessage({
        type: 'ADD_LEAD',
        lead: { ...lead, playbookId: pbId, playbookName: activePb?.name || '', source: 'linkedin_profile' }
      }, (res) => {
        const status = document.getElementById('fida-panel-status');
        if (res?.duplicate) {
          status.textContent = 'Already in queue!';
          status.style.color = '#f0c040';
          btn.textContent = '+ Add to Queue';
          btn.disabled = false;
        } else if (res?.ok) {
          status.textContent = `Added to ${activePb?.name || 'queue'}! (${res.count} total)`;
          status.style.color = '#27ae60';
          btn.textContent = '✓ Added';
          updateLeadCount(res.count);
        }
      });
    });
  }

  // ── Page type detection & main injection logic ───────────
  function getPageType() {
    const url = window.location.href;
    if (url.includes('/sales/search/')) return 'sales_search';
    if (url.includes('/sales/lead/') || url.includes('/sales/people/')) return 'sales_profile';
    if (url.includes('/search/results/people')) return 'li_search';
    if (url.includes('/in/') && !url.includes('/search/')) return 'li_profile';
    return 'other';
  }

  function injectButtons() {
    const pageType = getPageType();

    if (pageType === 'sales_search' || pageType === 'li_search') {
      // Find all lead result cards
      const cards = document.querySelectorAll(
        '.artdeco-list__item, ' +
        '[data-view-name="search-entity-result-universal-template"], ' +
        'li.result-lockup, ' +
        '.entity-result__item, ' +
        '[class*="result-container"]'
      );
      cards.forEach(card => injectAddButton(card));
    }

    if (pageType === 'li_profile' || pageType === 'sales_profile') {
      injectProfilePanel();
    }
  }

  // ── MutationObserver: watch for new cards as page scrolls ─
  function startObserver() {
    if (observer) observer.disconnect();
    observer = new MutationObserver(() => {
      injectButtons();
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  // ── Init ─────────────────────────────────────────────────
  function init() {
    loadState(() => {
      injectBar();
      injectButtons();
      startObserver();
    });
  }

  // Re-init on navigation (LinkedIn is a SPA)
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      setTimeout(() => {
        loadState(() => {
          updateBarPlaybooks();
          injectButtons();
          // Re-inject profile panel on new profile page
          const existing = document.getElementById('fida-profile-panel');
          if (existing) existing.remove();
          injectButtons();
        });
      }, 800); // wait for SPA content to render
    }
  }).observe(document, { subtree: true, childList: true });

  // Inject CSS for toast animation
  const style = document.createElement('style');
  style.textContent = `
    @keyframes fidaFadeIn {
      from { opacity: 0; transform: translateY(8px); }
      to   { opacity: 1; transform: translateY(0); }
    }
  `;
  document.head.appendChild(style);

  // Run init
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
