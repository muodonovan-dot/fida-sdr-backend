// LeadGeeks SDR — Content Script v2.2
// Profile-page extraction via innerText parsing (robust against DOM changes)

(function () {
  'use strict';

  let playbooks = [];
  let activePlaybookId = null;

  function init() {
    loadState(() => {
      injectBar();
      watchForPageChanges();
      // Only auto-capture if not opened by OPEN_AND_CAPTURE (which adds #fida-capture)
    if (isProfilePage() && !location.href.includes('#fida-capture')) {
      setTimeout(() => autoCapture(), 2500);
    }
      if (isListPage()) setTimeout(() => injectSaveButtons(), 2500);
    });
  }

  function loadState(cb) {
    chrome.runtime.sendMessage({ type: 'GET_PLAYBOOKS' }, (res) => {
      playbooks = res?.playbooks || [];
      chrome.runtime.sendMessage({ type: 'GET_ACTIVE_PLAYBOOK' }, (res2) => {
        activePlaybookId = res2?.activePlaybookId || playbooks[0]?.id || null;
        if (cb) cb();
      });
    });
  }

  function isProfilePage() {
    return /linkedin\.com\/sales\/lead\//.test(location.href) ||
           /linkedin\.com\/in\/[^/?]+/.test(location.href);
  }

  function isListPage() {
    return /linkedin\.com\/sales\/search\//.test(location.href) ||
           /linkedin\.com\/sales\/lists\//.test(location.href);
  }

  function watchForPageChanges() {
    let lastUrl = location.href;
    new MutationObserver(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        updateBar();
        if (isProfilePage() && !location.href.includes('#fida-capture')) {
          setTimeout(() => autoCapture(), 2500);
        }
        if (isListPage()) setTimeout(() => injectSaveButtons(), 2500);
      }
    }).observe(document.body, { childList: true, subtree: true });
  }

  // ── Extract ALL fields from a Sales Nav profile page via innerText ─────────
  // This is robust because it relies on page structure, not class names
  function extractProfileFromPage() {
    const lines = document.body.innerText.split('\n').map(l => l.trim()).filter(Boolean);

    // Find name: the H1 that isn't an a11y heading
    let first_name = '', last_name = '';
    const nameH1 = Array.from(document.querySelectorAll('h1'))
      .find(h => !h.className.includes('a11y') && h.textContent.trim().length > 2
                 && h.textContent.trim().length < 60
                 && !h.textContent.includes('Page')
                 && !h.textContent.includes('Get insights')
                 && !h.textContent.includes('Basic lead'));
    if (nameH1) {
      const parts = nameH1.textContent.trim().split(/\s+/);
      first_name = parts[0] || '';
      last_name = parts.slice(1).join(' ') || '';
    }
    if (!first_name) return null;

    const fullName = `${first_name} ${last_name}`.trim();
    const nameIdx = lines.findIndex(l => l === fullName);

    // Headline = line right after name (long text with pipes or keywords)
    const headline = nameIdx >= 0 ? (lines[nameIdx + 1] || '') : '';

    // Location — scan up to 7 lines after name for comma-separated location
    let city = '', state = '', country = '';
    for (let i = nameIdx + 1; i < nameIdx + 7 && i < lines.length; i++) {
      const l = lines[i];
      if (l.includes('United States') || l.includes('United Kingdom') || l.includes('Canada') || l.includes('Australia') ||
          (l.includes(',') && l.split(',').length >= 2 && l.length < 80 && !l.includes('|') && !l.includes('•') && !l.includes('@'))) {
        const locParts = l.split(',').map(p => p.trim());
        city = locParts[0] || ''; state = locParts[1] || ''; country = locParts[2] || '';
        break;
      }
    }

    // Current role: find "Current role" line, next line is "Title at Company"
    let job_title = '', organisation = '';
    const currentRoleIdx = lines.findIndex(l => l === 'Current role');
    if (currentRoleIdx >= 0) {
      const roleStr = lines[currentRoleIdx + 1] || '';
      const atIdx = roleStr.lastIndexOf(' at ');
      if (atIdx > 0) {
        job_title = roleStr.substring(0, atIdx).trim();
        organisation = roleStr.substring(atIdx + 4).trim();
      } else {
        job_title = roleStr;
      }
    }

    // LinkedIn URL (Sales Nav)
    const linkedin_url = location.href.split('?')[0];

    // Profile photo — highest res available
    let profile_photo_url = null;
    const imgs = document.querySelectorAll('img[src*="licdn"], img[src*="media.linkedin"]');
    for (const img of imgs) {
      if (img.src && !img.src.includes('ghost') && img.naturalWidth >= 80) {
        profile_photo_url = img.src;
        break;
      }
    }

    // Department hint from headline
    let department = '';
    if (headline) {
      const deptMatch = headline.match(/VP|Director|Head of|Manager|Principal|Senior|Lead|Chief|Officer|President/i);
      if (deptMatch) department = deptMatch[0];
    }

    return { first_name, last_name, job_title, organisation, city, state, country,
             linkedin_url, profile_photo_url, department, headline };
  }

  // ── Auto-capture when visiting a profile page ─────────────────────────────
  function autoCapture() {
    if (!activePlaybookId) return;
    const data = extractProfileFromPage();
    if (!data?.first_name) return;

    const lead = buildLead(data);
    chrome.runtime.sendMessage({ type: 'SAVE_LEAD', lead }, (res) => {
      if (res?.ok) {
        setStatus(`✅ ${data.first_name} ${data.last_name} saved`, '#00c87a');
        showToast(`✅ ${data.first_name} ${data.last_name} saved to LeadGeeks`);
      } else if (res?.error?.includes('User ID')) {
        setStatus('⚠️ Set User ID in extension popup', '#f0c040');
      }
    });
  }

  // ── Extract data from a list card ─────────────────────────────────────────
  // For list pages: name from a11y label, URN from data attribute
  // Title/company often missing — user should click through to profile for full data
  function extractCardData(card) {
    const a11y = card.querySelector('.a11y-text');
    const nameMatch = a11y?.textContent?.match(/Add (.+?) to selection/);
    const fullName = nameMatch?.[1]?.trim() || '';
    if (!fullName) return null;

    const parts = fullName.split(/\s+/);
    const first_name = parts[0] || '';
    const last_name = parts.slice(1).join(' ') || '';

    // Build profile URL from URN
    const urnEl = card.querySelector('[data-scroll-into-view]');
    const urnAttr = urnEl?.getAttribute('data-scroll-into-view') || '';
    const urnMatch = urnAttr.match(/fs_salesProfile:\(([^,)]+)/);
    const leadId = urnMatch?.[1] || '';
    const linkedin_url = leadId
      ? `https://www.linkedin.com/sales/lead/${leadId},NAME_SEARCH,/`
      : '';

    // Title + company from rendered article text (when available)
    let job_title = '', organisation = '';
    const article = card.querySelector('article[aria-hidden="true"]');
    if (article) {
      const cardLines = (article.innerText || '').split('\n').map(l => l.trim()).filter(Boolean);
      // Rendered card lines: [Name, Title at Company, Location, ...]
      const roleStr = cardLines.find(l => l.includes(' at ') && l !== fullName) || '';
      if (roleStr) {
        const atIdx = roleStr.lastIndexOf(' at ');
        job_title = roleStr.substring(0, atIdx).trim();
        organisation = roleStr.substring(atIdx + 4).trim();
      } else if (cardLines.length >= 2) {
        job_title = cardLines[1] || '';
      }
    }

    // Photo — take the first profile-displayphoto in the card
    // The card img with the longest alt text is most likely the person (not mutual connections)
    let profile_photo_url = null;
    const allImgs = card.querySelectorAll('img[src*="profile-displayphoto"], img[src*="profile-photo"]');
    let bestImg = null, bestAltLen = -1;
    for (const img of allImgs) {
      const src = img.src || '';
      if (!src || src.includes('ghost')) continue;
      const altLen = (img.alt || '').length;
      if (altLen > bestAltLen) { bestAltLen = altLen; bestImg = img; }
    }
    if (bestImg) {
      profile_photo_url = bestImg.src
        .replace('shrink_100_100', 'shrink_400_400')
        .replace('shrink_50_50', 'shrink_400_400')
        .replace('scale_100_100', 'shrink_400_400');
    }

    return { first_name, last_name, job_title, organisation, linkedin_url, profile_photo_url };
  }

  function buildLead(data) {
    return {
      id: 'lead_ext_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      playbook_id: activePlaybookId,
      first_name: data.first_name || '',
      last_name: data.last_name || '',
      job_title: data.job_title || '',
      organisation: data.organisation || '',
      city: data.city || '',
      state: data.state || '',
      country: data.country || '',
      linkedin_url: data.linkedin_url || '',
      profile_photo_url: data.profile_photo_url || null,
      department: data.department || '',
      source: 'linkedin_extension',
      status: 'new',
      added_at: Date.now()
    };
  }

  // ── Inject "+ Save" buttons on list pages ─────────────────────────────────
  function injectSaveButtons() {
    const cards = document.querySelectorAll('.artdeco-list__item');
    cards.forEach(card => {
      if (card.querySelector('.fida-save-btn')) return;
      const data = extractCardData(card);
      if (!data?.first_name) return;

      const anchor = card.querySelector('[data-scroll-into-view]')?.parentElement;
      if (!anchor) return;

      const btn = document.createElement('button');
      btn.className = 'fida-save-btn';
      btn.textContent = '+ Save';
      btn.title = `Save ${data.first_name} ${data.last_name} to LeadGeeks`;
      btn.style.cssText = 'display:inline-flex;align-items:center;margin-top:6px;margin-left:2px;padding:3px 10px;font-size:11px;font-weight:700;background:#EF4D05;color:#fff;border:none;border-radius:5px;cursor:pointer;font-family:-apple-system,sans-serif;white-space:nowrap;box-shadow:0 1px 4px rgba(239,77,5,.3)';
      btn.onclick = (e) => { e.preventDefault(); e.stopPropagation(); saveOne(data, btn); };
      anchor.appendChild(btn);
    });
    setTimeout(() => injectSaveButtons(), 4000);
  }

  function saveOne(data, btn) {
    if (!activePlaybookId) { showToast('Select a playbook first'); return; }
    if (!data.linkedin_url) {
      // No URL to enrich — save what we have
      btn.textContent = '⏳'; btn.disabled = true;
      const lead = buildLead(data);
      chrome.runtime.sendMessage({ type: 'SAVE_LEAD', lead }, (res) => {
        btn.textContent = res?.ok ? '✓' : '!';
        btn.style.background = res?.ok ? '#00c87a' : '#ef4444';
        if (!res?.ok) btn.disabled = false;
        if (res?.ok) showToast(`✅ ${data.first_name} ${data.last_name} saved`);
        else showToast('❌ ' + (res?.error || 'Save failed'));
      });
      return;
    }
    // Open profile in background tab, extract full data, then save
    // Append #fida-no-autocapture to URL so content script skips auto-save
    btn.textContent = '⏳'; btn.disabled = true;
    setStatus(`Loading ${data.first_name} ${data.last_name}...`, '#f0c040');
    const captureUrl = data.linkedin_url + (data.linkedin_url.includes('#') ? '' : '#fida-capture');
    chrome.runtime.sendMessage({
      type: 'OPEN_AND_CAPTURE',
      url: captureUrl,
      playbookId: activePlaybookId,
      partialData: data
    }, (res) => {
      if (res?.ok) {
        btn.textContent = '✓'; btn.style.background = '#00c87a';
        setStatus(`✅ ${data.first_name} ${data.last_name} saved`, '#00c87a');
        showToast(`✅ ${data.first_name} ${data.last_name} saved with full profile`);
      } else {
        // Fall back to saving partial data
        const lead = buildLead(data);
        chrome.runtime.sendMessage({ type: 'SAVE_LEAD', lead }, (res2) => {
          btn.textContent = res2?.ok ? '✓' : '!';
          btn.style.background = res2?.ok ? '#00c87a' : '#ef4444';
          if (!res2?.ok) btn.disabled = false;
          if (res2?.ok) showToast(`✅ ${data.first_name} ${data.last_name} saved (basic)`);
          else showToast('❌ ' + (res2?.error || 'Save failed'));
        });
      }
    });
  }

  // ── Save All — sequential with delay to avoid LinkedIn rate limiting ─────
  function saveAllVisible() {
    if (!activePlaybookId) { showToast('Select a playbook first'); return; }

    const cards = document.querySelectorAll('.artdeco-list__item');
    const queue = [];
    cards.forEach(card => {
      const data = extractCardData(card);
      if (data && data.first_name && data.linkedin_url) queue.push(data);
    });

    if (!queue.length) { showToast('No profiles found on page'); return; }

    const btn = document.getElementById('fida-save-all-btn');
    if (btn) { btn.textContent = `⏳ 0/${queue.length}`; btn.disabled = true; }
    setStatus(`Saving ${queue.length} profiles...`, '#f0c040');

    let saved = 0;
    let idx = 0;

    function processNext() {
      if (idx >= queue.length) {
        if (btn) { btn.textContent = `✅ ${saved}/${queue.length}`; btn.disabled = false; }
        setStatus(`✅ Saved ${saved} of ${queue.length}`, '#00c87a');
        showToast(`✅ Saved ${saved} of ${queue.length} leads`);
        setTimeout(() => setStatus('Ready', '#888'), 4000);
        return;
      }

      const data = queue[idx++];
      if (btn) btn.textContent = `⏳ ${idx}/${queue.length}`;
      setStatus(`📥 ${data.first_name} ${data.last_name} (${idx}/${queue.length})`, '#f0c040');

      chrome.runtime.sendMessage({
        type: 'OPEN_AND_CAPTURE',
        url: data.linkedin_url,
        playbookId: activePlaybookId,
        partialData: data
      }, (res) => {
        if (res && res.ok) saved++;
        // 600ms between calls — enough to avoid rate limiting
        setTimeout(processNext, 600);
      });
    }

    processNext();
  }

    // ── Bottom bar ────────────────────────────────────────────────────────────
  function injectBar() {
    if (document.getElementById('fida-bar')) return;
    const bar = document.createElement('div');
    bar.id = 'fida-bar';
    bar.innerHTML = `
      <div class="fida-logo">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="12" fill="#EF4D05"/>
          <path d="M7 8h10M7 12h7M7 16h5" stroke="#fff" stroke-width="2" stroke-linecap="round"/>
        </svg>
        LeadGeeks<span style="color:#EF4D05;margin-left:3px">SDR</span>
      </div>
      <div class="fida-divider"></div>
      <label style="font-size:11px;color:#aaa;white-space:nowrap">Playbook:</label>
      <select id="fida-pb-select" style="background:#1a1a2e;border:1px solid #333;color:#fff;border-radius:5px;padding:3px 8px;font-size:12px;cursor:pointer;max-width:200px"></select>
      <div class="fida-divider"></div>
      <div id="fida-status" style="font-size:12px;color:#888">Ready — auto-saves on profile visit</div>
      <div style="flex:1"></div>
      <a href="https://fida-sdr.netlify.app" target="_blank"
        style="font-size:12px;color:#EF4D05;text-decoration:none;font-weight:600;padding:4px 10px;border:1px solid rgba(239,77,5,.4);border-radius:5px;white-space:nowrap">
        Open App →
      </a>`;
    document.body.appendChild(bar);
    document.body.style.paddingBottom = '52px';
    buildPlaybookDropdown();

    document.getElementById('fida-pb-select')?.addEventListener('change', (e) => {
      activePlaybookId = e.target.value;
      chrome.runtime.sendMessage({ type: 'SET_ACTIVE_PLAYBOOK', id: activePlaybookId });
    });

    // Check User ID — show inline input if not set
    chrome.runtime.sendMessage({ type: 'GET_USER_ID' }, (res) => {
      if (!res?.userId) {
        showUserIdPrompt();
      }
    });

    // Save All button on list pages
    if (isListPage()) {
      const btn = document.createElement('button');
      btn.id = 'fida-save-all-btn';
      btn.textContent = '💾 Save All';
      btn.style.cssText = 'position:fixed;bottom:70px;right:20px;z-index:99998;background:#EF4D05;color:#fff;border:none;border-radius:8px;padding:9px 16px;font-size:13px;font-weight:700;cursor:pointer;font-family:-apple-system,sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.3)';
      btn.onclick = () => saveAllVisible();
      document.body.appendChild(btn);
    }
  }

  function showUserIdPrompt() {
    if (document.getElementById('fida-uid-input')) return;
    const statusEl = document.getElementById('fida-status');
    if (!statusEl) return;

    statusEl.innerHTML = '';
    statusEl.style.display = 'flex';
    statusEl.style.alignItems = 'center';
    statusEl.style.gap = '6px';

    const label = document.createElement('span');
    label.textContent = '⚠️ Paste User ID from app Settings:';
    label.style.cssText = 'color:#f0c040;font-size:11px;white-space:nowrap;flex-shrink:0';

    const input = document.createElement('input');
    input.id = 'fida-uid-input';
    input.type = 'text';
    input.placeholder = 'you@company.com';
    input.style.cssText = 'width:160px;padding:3px 7px;background:#1a1a2e;border:1px solid #f0c040;color:#fff;border-radius:5px;font-size:11px;font-family:-apple-system,sans-serif;outline:none;flex-shrink:0';

    const saveBtn = document.createElement('button');
    saveBtn.textContent = 'Save';
    saveBtn.style.cssText = 'padding:3px 10px;background:#EF4D05;color:#fff;border:none;border-radius:5px;font-size:11px;font-weight:700;cursor:pointer;font-family:-apple-system,sans-serif;flex-shrink:0';

    // Proper event listener — has access to chrome.runtime
    saveBtn.addEventListener('click', () => {
      const val = input.value.trim();
      if (!val) { input.style.borderColor = '#ef4444'; return; }
      chrome.runtime.sendMessage({ type: 'SET_USER_ID', userId: val }, () => {
        setStatus('✅ User ID saved — loading playbooks...', '#00c87a');
        // Reload playbooks
        chrome.runtime.sendMessage({ type: 'GET_PLAYBOOKS' }, (res) => {
          playbooks = res?.playbooks || [];
          buildPlaybookDropdown();
          setTimeout(() => setStatus('Ready', '#888'), 3000);
        });
      });
    });

    // Also save on Enter
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveBtn.click(); });

    statusEl.appendChild(label);
    statusEl.appendChild(input);
    statusEl.appendChild(saveBtn);
    setTimeout(() => input.focus(), 100);
  }

  function buildPlaybookDropdown() {
    const sel = document.getElementById('fida-pb-select');
    if (!sel) return;
    sel.innerHTML = playbooks.length
      ? playbooks.map(pb => `<option value="${pb.id}"${pb.id === activePlaybookId ? ' selected' : ''}>${pb.name}</option>`).join('')
      : '<option value="">Open app → set User ID first</option>';
    if (!activePlaybookId && playbooks.length) { activePlaybookId = playbooks[0].id; sel.value = activePlaybookId; }
  }

  function updateBar() {
    chrome.runtime.sendMessage({ type: 'GET_PLAYBOOKS' }, (res) => {
      playbooks = res?.playbooks || [];
      buildPlaybookDropdown();
    });
  }

  function setStatus(msg, color) {
    const s = document.getElementById('fida-status');
    if (!s) return;
    s.textContent = msg; s.style.color = color || '#888';
    if (color === '#00c87a') setTimeout(() => { s.textContent = 'Ready'; s.style.color = '#888'; }, 4000);
  }

  function showToast(msg) {
    document.getElementById('fida-toast')?.remove();
    const t = document.createElement('div');
    t.id = 'fida-toast'; t.textContent = msg;
    t.style.cssText = 'position:fixed;bottom:65px;left:50%;transform:translateX(-50%);background:#0f0d1e;border:1px solid #EF4D05;border-left:4px solid #EF4D05;color:#fff;padding:9px 16px;border-radius:8px;font-size:13px;font-weight:600;z-index:99999;box-shadow:0 4px 16px rgba(0,0,0,.4);font-family:-apple-system,sans-serif;white-space:nowrap';
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3500);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
