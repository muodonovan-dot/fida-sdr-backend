const statusEl = document.getElementById('statusMsg');
const userIdInput = document.getElementById('userIdInput');
const noUserWarning = document.getElementById('noUserWarning');
const pbSelect = document.getElementById('pbSelect');

// Load saved User ID
chrome.runtime.sendMessage({ type: 'GET_USER_ID' }, (res) => {
  const uid = res?.userId || '';
  userIdInput.value = uid;
  if (!uid) {
    noUserWarning.style.display = 'block';
  } else {
    loadPlaybooks();
  }
});

function saveUserId() {
  const val = userIdInput.value.trim();
  if (!val) {
    statusEl.textContent = 'Paste your User ID from the app Settings page';
    statusEl.className = 'status err';
    return;
  }
  chrome.runtime.sendMessage({ type: 'SET_USER_ID', userId: val }, () => {
    statusEl.textContent = '✅ Saved!';
    statusEl.className = 'status ok';
    noUserWarning.style.display = 'none';
    loadPlaybooks();
    setTimeout(() => { statusEl.textContent = ''; statusEl.className = 'status'; }, 2000);
  });
}

function openApp() {
  chrome.tabs.create({ url: 'https://fida-sdr.netlify.app' });
}

function loadPlaybooks() {
  pbSelect.innerHTML = '<option value="">Loading…</option>';
  chrome.runtime.sendMessage({ type: 'GET_PLAYBOOKS' }, (res) => {
    const pbs = res?.playbooks || [];
    if (!pbs.length) {
      pbSelect.innerHTML = '<option value="">No playbooks found — check User ID matches app</option>';
      return;
    }
    pbSelect.innerHTML = pbs.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
    chrome.runtime.sendMessage({ type: 'GET_ACTIVE_PLAYBOOK' }, (r) => {
      if (r?.activePlaybookId) pbSelect.value = r.activePlaybookId;
    });
  });
}

pbSelect.addEventListener('change', () => {
  if (pbSelect.value) {
    chrome.runtime.sendMessage({ type: 'SET_ACTIVE_PLAYBOOK', id: pbSelect.value });
  }
});
