// LeadGeeks SDR — Extension v2.6
// API-first, no background tabs, no DOM scraping

const SUPABASE_URL = 'https://cqsdsztzyvxtnzrruxeb.supabase.co';
const SUPABASE_KEY = 'sb_publishable_oWLb_blZHL_rayCldsPfMw_OoQs0HMR';

const STATE_MAP = {
  'Alabama':'AL','Alaska':'AK','Arizona':'AZ','Arkansas':'AR','California':'CA',
  'Colorado':'CO','Connecticut':'CT','Delaware':'DE','Florida':'FL','Georgia':'GA',
  'Hawaii':'HI','Idaho':'ID','Illinois':'IL','Indiana':'IN','Iowa':'IA',
  'Kansas':'KS','Kentucky':'KY','Louisiana':'LA','Maine':'ME','Maryland':'MD',
  'Massachusetts':'MA','Michigan':'MI','Minnesota':'MN','Mississippi':'MS','Missouri':'MO',
  'Montana':'MT','Nebraska':'NE','Nevada':'NV','New Hampshire':'NH','New Jersey':'NJ',
  'New Mexico':'NM','New York':'NY','North Carolina':'NC','North Dakota':'ND','Ohio':'OH',
  'Oklahoma':'OK','Oregon':'OR','Pennsylvania':'PA','Rhode Island':'RI','South Carolina':'SC',
  'South Dakota':'SD','Tennessee':'TN','Texas':'TX','Utah':'UT','Vermont':'VT',
  'Virginia':'VA','Washington':'WA','West Virginia':'WV','Wisconsin':'WI','Wyoming':'WY',
  'District of Columbia':'DC','Ontario':'ON','Quebec':'QC','British Columbia':'BC',
  'Alberta':'AB','Manitoba':'MB','Saskatchewan':'SK'
};

function getUserId() {
  return new Promise(function(r) { chrome.storage.local.get('fidaUserId', function(d) { r(d.fidaUserId||null); }); });
}

function getCsrf() {
  return new Promise(function(r) {
    chrome.cookies.get({ url:'https://www.linkedin.com', name:'JSESSIONID' }, function(c) { r(c ? c.value.replace(/"/g,'') : null); });
  });
}

function saveToSupabase(lead) {
  return fetch(SUPABASE_URL+'/rest/v1/leads', {
    method:'POST',
    headers:{ 'apikey':SUPABASE_KEY, 'Authorization':'Bearer '+SUPABASE_KEY, 'Content-Type':'application/json', 'Prefer':'resolution=merge-duplicates' },
    body:JSON.stringify(lead)
  }).then(function(r) { if(!r.ok) return r.text().then(function(t){throw new Error(t);}); return true; });
}

function fetchPlaybooks(userId) {
  return fetch(SUPABASE_URL+'/rest/v1/playbooks?select=id,name,color&user_id=eq.'+encodeURIComponent(userId)+'&order=created_at.asc',
    { headers:{ 'apikey':SUPABASE_KEY, 'Authorization':'Bearer '+SUPABASE_KEY } }
  ).then(function(r){ return r.ok ? r.json() : []; });
}

function urlToId(url) {
  var clean = (url||'').split('#')[0].replace('https://www.linkedin.com/sales/lead/','').split(',')[0];
  return 'li_'+clean.replace(/[^a-zA-Z0-9]/g,'').slice(0,24);
}

function abbrevState(s) { return STATE_MAP[s] || s; }

function extractUrn(url) {
  var m = (url||'').split('#')[0].match(/\/sales\/lead\/([^,\/]+)/);
  return m ? m[1] : null;
}

// ── LinkedIn Sales API ────────────────────────────────────────────────────────
function callLinkedInApi(urn, csrf) {
  // Use LinkedIn's exact decoration string (captured from network)
  var url = 'https://www.linkedin.com/sales-api/salesApiProfiles/(profileId:'+urn+',authType:NAME_SEARCH,authToken:undefined)?decoration=%28entityUrn%2CobjectUrn%2CfirstName%2ClastName%2CfullName%2Cheadline%2Clocation%2CsavedLead%2CdefaultPosition%2Cpositions%2A%28companyName%2Ccurrent%2Cnew%2CendedOn%2CstartedOn%2Ctitle%2CcompanyUrn%7Efs_salesCompany%28entityUrn%2Cname%2CcompanyPictureDisplayImage%29%29%2CprofilePictureDisplayImage%29';
  return fetch(url, {
    headers:{
      'csrf-token': csrf,
      'Accept': 'application/json',
      'X-RestLi-Protocol-Version': '2.0.0',
      'X-Li-Lang': 'en_US',
      'X-Li-Track': '{"clientVersion":"*","mpVersion":"*","osName":"web","timezoneOffset":-5,"timezone":"America/Chicago","deviceFormFactor":"DESKTOP","mpName":"sales-navigator-frontend"}'
    },
    credentials: 'include'
  }).then(function(r) {
    if (!r.ok) throw new Error('LI API '+r.status);
    return r.json();
  });
}

function parseApiData(d, fallbackUrl, partialData) {
  // Photo from profilePictureDisplayImage — must be a person photo not company logo
  var photo = null;
  try {
    var rootUrl = d.profilePictureDisplayImage && d.profilePictureDisplayImage.rootUrl;
    var artifacts = d.profilePictureDisplayImage && d.profilePictureDisplayImage.artifacts;
    if (rootUrl && artifacts && artifacts.length) {
      // Get the largest artifact
      var best = artifacts.reduce(function(a,b){ return (b.width||0)>(a.width||0)?b:a; }, artifacts[0]);
      var photoUrl = rootUrl + best.fileIdentifyingUrlPathSegment;
      // ONLY use if it's a person photo (contains profile-displayphoto), not company logo
      if (photoUrl.includes('profile-displayphoto') || photoUrl.includes('profile-photo')) {
        photo = photoUrl;
      }
    }
  } catch(e) {}

  // Fall back to card photo (already visible, already the right person)
  if (!photo && partialData && partialData.profile_photo_url) {
    var cardPhoto = partialData.profile_photo_url;
    // Only use if it's a person photo, not company logo
    if (!cardPhoto.includes('company-logo') && !cardPhoto.includes('organization-logo')) {
      photo = cardPhoto;
    }
  }

  // Location from "location" field (not geoRegion)
  var city='', state='', country='';
  var locationStr = d.location || d.geoRegion || '';
  if (locationStr) {
    var parts = locationStr.split(',').map(function(s){return s.trim();});
    if (parts.length >= 3) { city=parts[0]; state=abbrevState(parts[1]); country=parts[2]; }
    else if (parts.length===2) { city=parts[0]; country=parts[1]; }
    else { country=locationStr; }
  }

  // Current position from positions* array or defaultPosition
  var job_title='', organisation='';
  var allPos = d.positions || d.currentPositions || [];
  var pos = allPos.find(function(p){return p.current||p.new;})||allPos[0]||d.defaultPosition;
  if (pos) {
    job_title = pos.title||'';
    // Company name can be in companyName or nested in companyUrn
    organisation = pos.companyName || (pos['companyUrn~'] && pos['companyUrn~'].name) || '';
  }

  return {
    first_name: d.firstName||'',
    last_name: d.lastName||'',
    job_title: job_title,
    organisation: organisation,
    city: city, state: state, country: country,
    profile_photo_url: photo,
    linkedin_url: (fallbackUrl||'').split('#')[0]
  };
}

function buildLead(data, playbookId, userId) {
  var url = (data.linkedin_url||'').split('#')[0];
  var state = abbrevState(data.state||'');
  return {
    id: url ? urlToId(url) : 'lead_'+Date.now()+'_'+Math.random().toString(36).slice(2,7),
    playbook_id: playbookId, user_id: userId,
    first_name: data.first_name||'', last_name: data.last_name||'',
    job_title: data.job_title||'', organisation: data.organisation||'',
    city: data.city||'', state: state, country: data.country||'',
    linkedin_url: url,
    profile_photo_url: data.profile_photo_url||null,
    source: 'linkedin_extension', status: 'new', added_at: Date.now()
  };
}

// ── Main capture — API only, no background tab ────────────────────────────────
function captureViaApi(url, playbookId, userId, partialData, sendResponse) {
  var cleanUrl = url.split('#')[0];
  var urn = extractUrn(cleanUrl);

  if (!urn) {
    // No URN — save partial card data with deterministic ID from URL
    var lead = buildLead(Object.assign({}, partialData, { linkedin_url: cleanUrl }), playbookId, userId);
    saveToSupabase(lead).then(function(){ sendResponse({ok:true,partial:true}); }).catch(function(e){ sendResponse({ok:false,error:e.message}); });
    return;
  }

  getCsrf().then(function(csrf) {
    if (!csrf) {
      // No CSRF cookie — save partial data
      var lead = buildLead(Object.assign({}, partialData, {linkedin_url: cleanUrl}), playbookId, userId);
      return saveToSupabase(lead).then(function(){ sendResponse({ok:true,partial:true}); });
    }

    callLinkedInApi(urn, csrf)
      .then(function(apiData) {
        var extracted = parseApiData(apiData, cleanUrl, partialData);
        var lead = buildLead(extracted, playbookId, userId);
        return saveToSupabase(lead).then(function(){ sendResponse({ok:true}); });
      })
      .catch(function(err) {
        console.warn('[LeadGeeks] API error:', err.message, '— saving partial data');
        // API failed — save partial card data (has name + URL at minimum)
        var partial = Object.assign({}, partialData||{}, {linkedin_url: cleanUrl});
        var lead = buildLead(partial, playbookId, userId);
        saveToSupabase(lead).then(function(){ sendResponse({ok:true,partial:true}); }).catch(function(e){ sendResponse({ok:false,error:e.message}); });
      });
  });
}

// ── Message listener ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {

  if (msg.type === 'SAVE_LEAD') {
    getUserId().then(function(userId) {
      if (!userId) { sendResponse({ok:false,error:'No User ID'}); return; }
      var lead = Object.assign({},msg.lead,{user_id:userId});
      if (STATE_MAP[lead.state]) lead.state=STATE_MAP[lead.state];
      saveToSupabase(lead).then(function(){ sendResponse({ok:true}); }).catch(function(e){ sendResponse({ok:false,error:e.message}); });
    }); return true;
  }

  if (msg.type === 'SAVE_LEADS_BULK') {
    getUserId().then(function(userId) {
      if (!userId) { sendResponse({ok:false,error:'No User ID'}); return; }
      var leads = msg.leads.map(function(l){ var s=abbrevState(l.state||''); return Object.assign({},l,{user_id:userId,state:s}); });
      Promise.all(leads.map(saveToSupabase))
        .then(function(){ sendResponse({ok:true,saved:leads.length}); })
        .catch(function(e){ sendResponse({ok:false,error:e.message}); });
    }); return true;
  }

  if (msg.type === 'GET_PLAYBOOKS') {
    getUserId().then(function(userId) {
      if (!userId) { sendResponse({playbooks:[]}); return; }
      fetchPlaybooks(userId).then(function(pbs){ sendResponse({playbooks:pbs}); }).catch(function(){ sendResponse({playbooks:[]}); });
    }); return true;
  }

  if (msg.type === 'GET_ACTIVE_PLAYBOOK') {
    chrome.storage.local.get('activePlaybookId', function(d){ sendResponse({activePlaybookId:d.activePlaybookId||null}); }); return true;
  }

  if (msg.type === 'SET_ACTIVE_PLAYBOOK') {
    chrome.storage.local.set({activePlaybookId:msg.id}, function(){ sendResponse({ok:true}); }); return true;
  }

  if (msg.type === 'GET_USER_ID') {
    chrome.storage.local.get('fidaUserId', function(d){ sendResponse({userId:d.fidaUserId||null}); }); return true;
  }

  if (msg.type === 'SET_USER_ID') {
    chrome.storage.local.set({fidaUserId:msg.userId}, function(){ sendResponse({ok:true}); }); return true;
  }

  if (msg.type === 'OPEN_AND_CAPTURE') {
    getUserId().then(function(userId) {
      if (!userId) { sendResponse({ok:false,error:'No User ID'}); return; }
      captureViaApi(msg.url, msg.playbookId, userId, msg.partialData, sendResponse);
    }); return true;
  }
});
