// LeadGeeks Chrome Extension — Content Script
// Runs on LinkedIn pages and injects "Save to LeadGeeks" buttons

const LEADGEEKS_URL = 'https://fida-sdr.netlify.app';

function getProfileData() {
  // Name
  const nameEl = document.querySelector('h1.text-heading-xlarge, h1.inline.t-24, .pv-text-details__left-panel h1');
  const name = nameEl?.textContent?.trim() || '';
  const nameParts = name.split(' ');
  const firstName = nameParts[0] || '';
  const lastName = nameParts.slice(1).join(' ') || '';

  // Title
  const titleEl = document.querySelector('.text-body-medium.break-words, .pv-text-details__left-panel .text-body-medium');
  const jobTitle = titleEl?.textContent?.trim() || '';

  // Company & location
  const companyEl = document.querySelector('[aria-label*="Current company"] span, .pv-text-details__right-panel .t-14');
  const organisation = companyEl?.textContent?.trim() || '';

  const locationEl = document.querySelector('.pv-text-details__left-panel .pb2 span.text-body-small');
  const location = locationEl?.textContent?.trim() || '';

  // LinkedIn URL
  const linkedinUrl = window.location.href.split('?')[0];

  // Email (rarely public, but try)
  const emailEl = document.querySelector('a[href^="mailto:"]');
  const email = emailEl ? emailEl.href.replace('mailto:', '') : '';

  return { firstName, lastName, jobTitle, organisation, location, email, linkedinUrl };
}

function injectButton() {
  // Don't inject twice
  if (document.getElementById('leadgeeks-btn')) return;

  // Find the action buttons area on a profile page
  const actionArea = document.querySelector('.pvs-profile-actions, .pv-top-card-v2-ctas, .ph5.pb5');
  if (!actionArea) return;

  const btn = document.createElement('button');
  btn.id = 'leadgeeks-btn';
  btn.innerHTML = '🧬 Save to LeadGeeks';
  btn.style.cssText = `
    display: inline-flex; align-items: center; gap: 6px;
    padding: 8px 16px; border-radius: 6px; border: 2px solid #EF4D05;
    background: rgba(239,77,5,0.1); color: #EF4D05;
    font-size: 14px; font-weight: 600; cursor: pointer;
    margin-left: 8px; transition: all 0.15s; font-family: system-ui;
    white-space: nowrap;
  `;

  btn.onmouseenter = () => {
    btn.style.background = 'rgba(239,77,5,0.2)';
  };
  btn.onmouseleave = () => {
    btn.style.background = 'rgba(239,77,5,0.1)';
  };

  btn.onclick = () => {
    const data = getProfileData();
    saveLead(data, btn);
  };

  actionArea.appendChild(btn);
}

function saveLead(data, btn) {
  btn.innerHTML = '⏳ Saving...';
  btn.disabled = true;

  // Get stored playbook ID from extension storage
  chrome.storage.local.get(['activePlaybookId', 'supabaseKey'], (stored) => {
    const lead = {
      id: 'li_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email || '',
      jobTitle: data.jobTitle,
      organisation: data.organisation,
      country: data.location,
      focusedAreas: '',
      linkedinUrl: data.linkedinUrl,
      status: 'new',
      source: 'linkedin',
      createdAt: new Date().toISOString()
    };

    // Send to LeadGeeks app via postMessage (if app is open in another tab)
    // Also store locally so user can sync manually
    chrome.storage.local.get(['pendingLeads'], (res) => {
      const pending = res.pendingLeads || [];
      pending.push({ lead, playbookId: stored.activePlaybookId, savedAt: new Date().toISOString() });
      chrome.storage.local.set({ pendingLeads: pending }, () => {
        btn.innerHTML = '✅ Saved!';
        btn.style.borderColor = '#00c87a';
        btn.style.color = '#00c87a';
        btn.style.background = 'rgba(0,200,122,0.1)';

        // Show toast
        showToast(`${data.firstName} ${data.lastName} saved to LeadGeeks`);

        setTimeout(() => {
          btn.innerHTML = '🧬 Saved to LeadGeeks';
          btn.disabled = false;
        }, 3000);
      });
    });
  });
}

function showToast(message) {
  const existing = document.getElementById('leadgeeks-toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.id = 'leadgeeks-toast';
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed; bottom: 24px; right: 24px; z-index: 99999;
    background: #171151; border: 1px solid #EF4D05; color: #fff;
    padding: 12px 20px; border-radius: 8px; font-size: 14px;
    font-family: system-ui; font-weight: 500; box-shadow: 0 4px 20px rgba(0,0,0,0.4);
    animation: lgSlideIn 0.3s ease;
  `;

  const style = document.createElement('style');
  style.textContent = `@keyframes lgSlideIn { from { transform: translateY(20px); opacity:0 } to { transform: translateY(0); opacity:1 } }`;
  document.head.appendChild(style);
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

// Inject button when page loads and on navigation (LinkedIn is SPA)
function tryInject() {
  setTimeout(injectButton, 1500);
}

tryInject();

// Watch for LinkedIn SPA navigation
const observer = new MutationObserver(() => {
  if (window.location.pathname.includes('/in/') && !document.getElementById('leadgeeks-btn')) {
    tryInject();
  }
});
observer.observe(document.body, { childList: true, subtree: true });
